package ejercicio03;

public class Operaciones {

	
	public int sacarSigno (int num) {
		
		return num;
		
	}
	
	public boolean comprobarSigno (int num) {
		
		if (num>=0) {			
			return true;		
		}else {
			return false;
		}
	}
	
	public void mostrarResultado () {
		
		
		
	}
	
	
	
	
}
