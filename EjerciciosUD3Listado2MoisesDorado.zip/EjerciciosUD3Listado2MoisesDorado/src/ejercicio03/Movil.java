package ejercicio03;

public class Movil {

	private String marca;
	// MODELO
	private boolean vendido;
	private boolean nuevo;
	private double precioUni;
	
	
}
