package ejercicio03;

public class Vendedor {

}
